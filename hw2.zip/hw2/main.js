// initiate highlight for code display area
hljs.highlightAll();

// global variants for keyword highlight
var offsetTopArr = [];
var nowFloor = -1;

// scroll animate appear effect
function animateFrom(elem, direction) {
    var x = 0,
        y = direction * 150;
    if (elem.classList.contains("gs_reveal_fromLeft")) {
        x = -150;
        y = 0;
    } else if (elem.classList.contains("gs_reveal_fromRight")) {
        x = 150;
        y = 0;
    }
    elem.style.transform = "translate(" + x + "px, " + y + "px)";
    elem.style.opacity = "0";
    gsap.fromTo(elem, {
        x: x,
        y: y,
        autoAlpha: 0
    }, {
        delay: 0.5,
        duration: 2,
        x: 0,
        y: 0,
        autoAlpha: 1,
        ease: "expo",
        overwrite: "auto"
    });
}
// scroll animate hide effect
function hide(elem) {
    gsap.set(elem, {
        autoAlpha: 0
    });
}

document.addEventListener('DOMContentLoaded', function () {
    // initiate and bind title animation
    var titleAnime = anime({
        targets: "#webtitle path",
        strokeDashoffset: [anime.setDashoffset, 0],
        easing: "easeInOutSine",
        duration: 1500,
        delay: function (el, i) {
            return i * 100;
        },
        direction: "alternate",
        autoplay: false
    });
    titleAnime.restart();
    document.querySelector('#webtitle').onmouseout = titleAnime.restart;

    // drawer control
    const drawer = document.querySelector('.drawer-contact');
    const openButton = document.querySelector('#nave-right');
    openButton.addEventListener('click', function () {
        drawer.show();
    });

    // bind audios & update class for all menu-link elements when clicked
    const snd = new Audio("resources/click.mp3");
    var menuLinks = document.querySelectorAll('.menu-link');
    menuLinks.forEach(function (elem) {
        elem.addEventListener('click', function () {
            snd.play(); // add click audio

            // remove exist active
            menuLinks.forEach(function (innerElem) {
                innerElem.classList.remove('active');
            });
            // add new active
            elem.classList.add("active");
        });
    });

    // initiate carousel
    new Splide('#splide', {
        type: 'loop',
        perPage: 3,
        focus: 'center',
        autoplay: true,
        interval: 8000,
        flickMaxPages: 3,
        updateOnMove: true,
        pagination: false,
        padding: '10%',
        throttle: 300,
        breakpoints: {
            1440: {
                perPage: 1,
                padding: '30%'
            }
        }
    }).mount();

    // scrollTrigger animate
    gsap.registerPlugin(ScrollTrigger);
    gsap.utils.toArray(".gs_reveal").forEach(function (elem) {
        hide(elem);
        ScrollTrigger.create({
            trigger: elem,
            onEnter: function () {
                animateFrom(elem, 1);
            },
            onEnterBack: function () {
                animateFrom(elem, -1);
            },
            onLeave: function () {
                hide(elem);
            }
        });
    });

    // video play
    const container = document.querySelector('.animation-form');
    const animation = container.querySelectorAll('sl-animation');
    const video_button = container.querySelectorAll('sl-button');
    for (var j = 0; j < video_button.length; j++) {
        video_button[j].addEventListener('click', function (e) {
            // play button animation
            let index = e.target.getAttribute('data-index');
            animation[index].play = true;
            // set iframe url
            let url = e.target.getAttribute('data-url');
            let frame = document.getElementById('ifrId');
            frame.setAttribute('src', url);
            // make tip text invisible
            document.getElementsByClassName("iframe-content-text")[0].style.visibility = "hidden";
        });
    }

});

// update offsetTopArr
function updateOffsetTop () {
    offsetTopArr = [];
    var contents = document.querySelectorAll('.nav-link');
    for (var i = 0; i < contents.length; i++) {
        offsetTopArr.push(contents[i].offsetTop);
    }
}

// initiate offsetTopArr when window is loaded
window.addEventListener('load', updateOffsetTop);

// update offsetTopArr when window is resized
window.addEventListener("resize", updateOffsetTop);

// window scroll features: keyword highlight & progress bar
window.onscroll = function () {
    // get current position and set corresponding keyword highlight
    var nowScrollTop = document.documentElement.scrollTop;
    var lis = document.querySelectorAll('.sidebar a');
    var i = 0;
    for (i; i < offsetTopArr.length; i++) {
        if (nowScrollTop + 67 >= offsetTopArr[i] && nowScrollTop + 67 < offsetTopArr[i + 1]) {
            break;
        }
    }
    if (nowFloor != i) {
        nowFloor = i;
        for (var j = 0; j < lis.length; j++) {
            if (j == i) {
                lis[j].className = 'menu-link active';
            } else {
                lis[j].className = 'menu-link';
            }
        }
    }
    // update prograss bar position
    var offsetHeight = document.getElementsByClassName("content-box")[0].clientHeight;
    let contentHeight = document.getElementsByClassName('sidebar-inner')[0].offsetHeight;
    let percent = (nowScrollTop / (offsetHeight - contentHeight)).toFixed(2) * 100;
    const progressWidth = percent + '%';
    const svgCurrentLeft = parseInt(percent);
    const svgLeft = (svgCurrentLeft <= 2 ? svgCurrentLeft + '%' : svgCurrentLeft - 2 + '%');
    document.getElementsByClassName("progress-current")[0].style.width = progressWidth;
    document.getElementsByClassName("svg-content")[0].style.left = svgLeft;
};